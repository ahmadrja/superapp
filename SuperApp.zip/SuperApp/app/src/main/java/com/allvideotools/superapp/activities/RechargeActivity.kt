package com.allvideotools.superapp.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R
import com.allvideotools.superapp.api.ApiClient
import com.allvideotools.superapp.utils.SessionManager
import kotlinx.android.synthetic.main.activity_recharge.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RechargeActivity : AppCompatActivity() {

    private lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_recharge)

        session = SessionManager(this)

        btnRecharge.setOnClickListener {

            val number = etMobile.text.toString().trim()
            val operator = etOperator.text.toString().trim()
            val amount = etAmount.text.toString().trim()

            if(number.isEmpty()){
                etMobile.error = "Enter mobile number"
                return@setOnClickListener
            }

            if(operator.isEmpty()){
                etOperator.error = "Enter operator"
                return@setOnClickListener
            }

            if(amount.isEmpty()){
                etAmount.error = "Enter amount"
                return@setOnClickListener
            }

            val map = HashMap<String,String>()

            map["user_id"] = session.getUser().toString()
            map["number"] = number
            map["operator"] = operator
            map["amount"] = amount

            ApiClient.instance.mobileRecharge(map)
                .enqueue(object : Callback<Map<String,String>>{

                    override fun onResponse(
                        call: Call<Map<String,String>>,
                        response: Response<Map<String,String>>
                    ) {

                        val message = response.body()?.get("message")

                        Toast.makeText(
                            this@RechargeActivity,
                            message,
                            Toast.LENGTH_SHORT
                        ).show()

                        etMobile.text.clear()
                        etOperator.text.clear()
                        etAmount.text.clear()

                    }

                    override fun onFailure(call: Call<Map<String,String>>, t: Throwable) {

                        Toast.makeText(
                            this@RechargeActivity,
                            "Server error",
                            Toast.LENGTH_SHORT
                        ).show()

                    }

                })

        }

    }

}