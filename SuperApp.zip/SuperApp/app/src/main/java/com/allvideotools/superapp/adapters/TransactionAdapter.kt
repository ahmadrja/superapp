package com.allvideotools.superapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.allvideotools.superapp.databinding.ItemTransactionBinding
import com.allvideotools.superapp.models.Transaction

class TransactionAdapter(
    private val list: List<Transaction>
):RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemTransactionBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val binding = ItemTransactionBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = list[position]

        holder.binding.tvAmount.text = "₹ "+item.amount
        holder.binding.tvType.text = item.type
        holder.binding.tvStatus.text = item.status
        holder.binding.tvDate.text = item.created_at
    }

    override fun getItemCount(): Int = list.size
}