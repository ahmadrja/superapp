package com.allvideotools.superapp.api

import com.allvideotools.superapp.models.*
import retrofit2.Call
import retrofit2.http.*

interface ApiService {

    @POST("auth/login.php")
    fun login(@Body request: LoginRequest): Call<LoginResponse>

    @GET("wallet/balance.php")
    fun wallet(@Query("user_id") userId:Int): Call<Map<String,String>>

    @GET("transactions/history.php")
    fun transactions(@Query("user_id") userId:Int): Call<List<Transaction>>

    @POST("bank/add_beneficiary.php")
    fun addBeneficiary(@Body data: Map<String,String>): Call<Map<String,String>>

    @POST("bank/transfer.php")
    fun bankTransfer(@Body data: Map<String,String>): Call<Map<String,String>>

    @GET("recharge/plans.php")
    fun getPlans(
        @Query("operator") operator:String
    ): Call<List<RechargePlan>>

    @POST("bill/pay.php")
    fun payBill(@Body data: Map<String,String>): Call<Map<String,String>>

}