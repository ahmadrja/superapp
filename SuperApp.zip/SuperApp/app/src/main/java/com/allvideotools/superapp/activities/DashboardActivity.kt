package com.allvideotools.superapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.databinding.ActivityDashboardBinding

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnMobile.setOnClickListener {
            startActivity(Intent(this, RechargeActivity::class.java))
        }

        binding.btnElectricity.setOnClickListener {
            startActivity(Intent(this, BillPaymentActivity::class.java))
        }

        binding.btnWallet.setOnClickListener {
            startActivity(Intent(this, WalletActivity::class.java))
        }

        binding.btnTransactions.setOnClickListener {
            startActivity(Intent(this, TransactionsActivity::class.java))
        }

        binding.btnRechargePlans.setOnClickListener {
            startActivity(Intent(this, RechargePlansActivity::class.java))
        }

        binding.btnProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
    }
}