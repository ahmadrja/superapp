package com.allvideotools.superapp.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R
import com.allvideotools.superapp.api.ApiClient
import com.allvideotools.superapp.models.LoginRequest
import com.allvideotools.superapp.models.LoginResponse
import com.allvideotools.superapp.utils.SessionManager
import kotlinx.android.synthetic.main.activity_login.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    lateinit var session: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        session = SessionManager(this)

        // Auto login
        if(session.getUser() != 0){
            startActivity(Intent(this, DashboardActivity::class.java))
            finish()
        }

        btnLogin.setOnClickListener {

            val mobile = etMobile.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if(mobile.isEmpty()){
                etMobile.error = "Enter mobile number"
                return@setOnClickListener
            }

            if(password.isEmpty()){
                etPassword.error = "Enter password"
                return@setOnClickListener
            }

            val request = LoginRequest(mobile, password)

            ApiClient.instance.login(request)
                .enqueue(object : Callback<LoginResponse>{

                    override fun onResponse(
                        call: Call<LoginResponse>,
                        response: Response<LoginResponse>
                    ) {

                        val body = response.body()

                        if(body?.status == "success"){

                            // Save session
                            session.saveUser(body.user!!.id)

                            Toast.makeText(
                                this@LoginActivity,
                                "Login Successful",
                                Toast.LENGTH_SHORT
                            ).show()

                            startActivity(
                                Intent(
                                    this@LoginActivity,
                                    DashboardActivity::class.java
                                )
                            )

                            finish()

                        }else{

                            Toast.makeText(
                                this@LoginActivity,
                                "Invalid login",
                                Toast.LENGTH_SHORT
                            ).show()

                        }

                    }

                    override fun onFailure(call: Call<LoginResponse>, t: Throwable) {

                        Toast.makeText(
                            this@LoginActivity,
                            "Server error",
                            Toast.LENGTH_SHORT
                        ).show()

                    }

                })

        }

    }
}