package com.allvideotools.superapp.models

data class RechargePlan(
    val id:Int,
    val operator:String,
    val circle:String,
    val amount:String,
    val validity:String,
    val description:String
)