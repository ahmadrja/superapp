package com.allvideotools.superapp.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R

class KycActivity:AppCompatActivity(){

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_kyc)

    }

}