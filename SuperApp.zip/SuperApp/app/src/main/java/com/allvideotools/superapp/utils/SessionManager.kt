package com.allvideotools.superapp.utils

import android.content.Context

class SessionManager(context: Context) {

    private val prefs =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREF_NAME = "superapp_session"
        private const val KEY_USER_ID = "user_id"
    }

    // Save user session
    fun saveUser(userId: Int) {
        prefs.edit().putInt(KEY_USER_ID, userId).apply()
    }

    // Get logged user id
    fun getUser(): Int {
        return prefs.getInt(KEY_USER_ID, 0)
    }

    // Check login status
    fun isLoggedIn(): Boolean {
        return getUser() != 0
    }

    // Logout user
    fun logout() {
        prefs.edit().clear().apply()
    }
}