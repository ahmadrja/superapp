package com.allvideotools.superapp.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R
import com.allvideotools.superapp.api.ApiClient
import kotlinx.android.synthetic.main.activity_bank_transfer.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BankTransferActivity:AppCompatActivity(){

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_bank_transfer)

        btnTransfer.setOnClickListener{

            val map = HashMap<String,String>()

            map["user_id"]="1"
            map["beneficiary_id"]="1"
            map["amount"]=etAmount.text.toString()

            ApiClient.instance.bankTransfer(map)
                .enqueue(object:Callback<Map<String,String>>{

                    override fun onResponse(
                        call:Call<Map<String,String>>,
                        response:Response<Map<String,String>>
                    ){

                        Toast.makeText(
                            this@BankTransferActivity,
                            response.body()?.get("message"),
                            Toast.LENGTH_SHORT
                        ).show()

                    }

                    override fun onFailure(call:Call<Map<String,String>>,t:Throwable){}

                })

        }

    }

}