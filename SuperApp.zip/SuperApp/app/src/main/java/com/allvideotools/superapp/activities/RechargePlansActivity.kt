package com.allvideotools.superapp.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.allvideotools.superapp.adapters.PlansAdapter
import com.allvideotools.superapp.api.ApiClient
import com.allvideotools.superapp.databinding.ActivityPlansBinding
import com.allvideotools.superapp.models.RechargePlan
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RechargePlansActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlansBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPlansBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvPlans.layoutManager = LinearLayoutManager(this)

        loadPlans()
    }

    private fun loadPlans() {

        ApiClient.instance.getPlans("Jio")
            .enqueue(object : Callback<List<RechargePlan>> {

                override fun onResponse(
                    call: Call<List<RechargePlan>>,
                    response: Response<List<RechargePlan>>
                ) {

                    val plans = response.body()

                    if (plans != null) {
                        binding.rvPlans.adapter = PlansAdapter(plans)
                    } else {
                        Toast.makeText(
                            this@RechargePlansActivity,
                            "No plans found",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<List<RechargePlan>>, t: Throwable) {

                    Toast.makeText(
                        this@RechargePlansActivity,
                        "Server error",
                        Toast.LENGTH_SHORT
                    ).show()

                }

            })
    }
}