package com.allvideotools.superapp.models

data class User(
    val id:Int,
    val name:String,
    val mobile:String
)