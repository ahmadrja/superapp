package com.allvideotools.superapp.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R
import com.allvideotools.superapp.api.ApiClient
import kotlinx.android.synthetic.main.activity_wallet.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class WalletActivity:AppCompatActivity(){

    override fun onCreate(savedInstanceState:Bundle?){

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_wallet)

        ApiClient.instance.wallet(1)
            .enqueue(object:Callback<Map<String,String>>{

                override fun onResponse(
                    call:Call<Map<String,String>>,
                    response:Response<Map<String,String>>
                ){

                    val balance = response.body()?.get("balance")

                    tvBalance.text = "₹ $balance"

                }

                override fun onFailure(call:Call<Map<String,String>>,t:Throwable){}

            })

    }
}