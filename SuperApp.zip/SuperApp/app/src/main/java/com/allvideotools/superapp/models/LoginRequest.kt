package com.allvideotools.superapp.models

data class LoginRequest(
    val mobile:String,
    val password:String
)