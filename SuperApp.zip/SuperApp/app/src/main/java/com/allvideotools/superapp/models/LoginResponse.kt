package com.allvideotools.superapp.models

data class LoginResponse(
    val status:String,
    val user:User?
)