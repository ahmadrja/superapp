package com.allvideotools.superapp.activities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R
import kotlinx.android.synthetic.main.activity_register.*

class RegisterActivity:AppCompatActivity(){

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_register)

        btnRegister.setOnClickListener{

            startActivity(Intent(this,LoginActivity::class.java))

        }

    }

}