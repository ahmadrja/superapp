package com.allvideotools.superapp.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.allvideotools.superapp.R
import com.allvideotools.superapp.adapters.TransactionAdapter
import com.allvideotools.superapp.api.ApiClient
import com.allvideotools.superapp.models.Transaction
import kotlinx.android.synthetic.main.activity_transactions.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TransactionsActivity:AppCompatActivity(){

    override fun onCreate(savedInstanceState:Bundle?){

        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_transactions)

        rvTransactions.layoutManager = LinearLayoutManager(this)

        ApiClient.instance.transactions(1)
            .enqueue(object:Callback<List<Transaction>>{

                override fun onResponse(
                    call:Call<List<Transaction>>,
                    response:Response<List<Transaction>>
                ){

                    val list = response.body()

                    rvTransactions.adapter = TransactionAdapter(list!!)

                }

                override fun onFailure(call:Call<List<Transaction>>,t:Throwable){}

            })

    }
}