package com.allvideotools.superapp.activities

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.allvideotools.superapp.R
import com.allvideotools.superapp.api.ApiClient
import com.allvideotools.superapp.utils.SessionManager
import kotlinx.android.synthetic.main.activity_bill_payment.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BillPaymentActivity:AppCompatActivity(){

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_bill_payment)

        val session = SessionManager(this)

        btnPayBill.setOnClickListener{

            val map = HashMap<String,String>()

            map["user_id"] = session.getUser().toString()
            map["bill_type"] = etType.text.toString()
            map["consumer_number"] = etConsumer.text.toString()
            map["operator"] = etOperator.text.toString()
            map["amount"] = etAmount.text.toString()

            ApiClient.instance.payBill(map)
                .enqueue(object:Callback<Map<String,String>>{

                    override fun onResponse(
                        call:Call<Map<String,String>>,
                        response:Response<Map<String,String>>
                    ){

                        Toast.makeText(
                            this@BillPaymentActivity,
                            response.body()?.get("message"),
                            Toast.LENGTH_SHORT
                        ).show()

                    }

                    override fun onFailure(call:Call<Map<String,String>>,t:Throwable){}

                })

        }

    }

}