package com.allvideotools.superapp.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.allvideotools.superapp.databinding.ItemPlanBinding
import com.allvideotools.superapp.models.RechargePlan

class PlansAdapter(
    private val plans: List<RechargePlan>
) : RecyclerView.Adapter<PlansAdapter.PlanViewHolder>() {

    class PlanViewHolder(val binding: ItemPlanBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanViewHolder {

        val binding = ItemPlanBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )

        return PlanViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PlanViewHolder, position: Int) {

        val plan = plans[position]

        holder.binding.tvAmount.text = "₹${plan.amount}"
        holder.binding.tvValidity.text = plan.validity
        holder.binding.tvDescription.text = plan.description
    }

    override fun getItemCount(): Int {
        return plans.size
    }
}