<?php

header("Content-Type: application/json");

require '../../config/database.php';

$user_id = $_GET['user_id'];

$stmt = $conn->prepare("
SELECT * FROM transactions
WHERE user_id=?
ORDER BY id DESC
");

$stmt->execute([$user_id]);

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($data);

?>