<?php

require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"),true);

$user_id = $data['user_id'];
$number = $data['number'];
$operator = $data['operator'];
$amount = $data['amount'];

/* CHECK WALLET */

$stmt = $conn->prepare("SELECT balance FROM wallet WHERE user_id=?");
$stmt->execute([$user_id]);
$wallet = $stmt->fetch(PDO::FETCH_ASSOC);

if($wallet['balance'] < $amount){

echo json_encode([
"status"=>"error",
"message"=>"Insufficient balance"
]);

exit;

}

/* WALLET DEDUCT */

$conn->prepare("
UPDATE wallet SET balance = balance - ?
WHERE user_id=?
")->execute([$amount,$user_id]);

/* SAVE RECHARGE */

$conn->prepare("
INSERT INTO recharges(user_id,number,operator,amount,status)
VALUES(?,?,?,?, 'success')
")->execute([$user_id,$number,$operator,$amount]);

/* COMMISSION CALCULATION */

$op = $conn->prepare("
SELECT commission FROM operators WHERE name=?
");

$op->execute([$operator]);

$opdata = $op->fetch(PDO::FETCH_ASSOC);

$commission = ($amount * $opdata['commission'])/100;

/* ADD COMMISSION */

$conn->prepare("
UPDATE wallet SET balance = balance + ?
WHERE user_id=?
")->execute([$commission,$user_id]);

/* TRANSACTION LOG */

$conn->prepare("
INSERT INTO transactions(user_id,amount,type,status)
VALUES(?,?, 'debit','success')
")->execute([$user_id,$amount]);

echo json_encode([
"status"=>"success",
"message"=>"Recharge successful"
]);

?>