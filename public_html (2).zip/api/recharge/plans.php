<?php

header("Content-Type: application/json");

require '../../config/database.php';

$operator = $_GET['operator'];

$stmt = $conn->prepare("
SELECT * FROM recharge_plans
WHERE operator=?
");

$stmt->execute([$operator]);

$data = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($data);

?>