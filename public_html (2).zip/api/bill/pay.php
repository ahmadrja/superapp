<?php

header("Content-Type: application/json");

require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"),true);

$user_id = $data['user_id'];
$type = $data['bill_type'];
$consumer = $data['consumer_number'];
$operator = $data['operator'];
$amount = $data['amount'];

/* CHECK WALLET */

$stmt = $conn->prepare("SELECT balance FROM wallet WHERE user_id=?");
$stmt->execute([$user_id]);

$wallet = $stmt->fetch(PDO::FETCH_ASSOC);

if($wallet['balance'] < $amount){

echo json_encode([
"status"=>"error",
"message"=>"Insufficient balance"
]);

exit;

}

/* WALLET DEDUCT */

$conn->prepare("
UPDATE wallet SET balance = balance - ?
WHERE user_id=?
")->execute([$amount,$user_id]);

/* SAVE BILL PAYMENT */

$conn->prepare("
INSERT INTO bill_payments(user_id,bill_type,consumer_number,operator,amount,status)
VALUES(?,?,?,?,?, 'success')
")->execute([$user_id,$type,$consumer,$operator,$amount]);

/* TRANSACTION LOG */

$conn->prepare("
INSERT INTO transactions(user_id,amount,type,status)
VALUES(?,?, 'debit','success')
")->execute([$user_id,$amount]);

echo json_encode([
"status"=>"success",
"message"=>"Bill paid successfully"
]);

?>