<?php

header("Content-Type: application/json");

require '../../config/database.php';

$user_id = $_GET['user_id'];

$stmt = $conn->prepare("SELECT balance FROM wallet WHERE user_id=?");
$stmt->execute([$user_id]);

$data = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($data);

?>