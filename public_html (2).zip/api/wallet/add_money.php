<?php

require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"),true);

$user_id = $data['user_id'];
$amount = $data['amount'];

$conn->prepare("
UPDATE wallet SET balance = balance + ?
WHERE user_id=?
")->execute([$amount,$user_id]);

$conn->prepare("
INSERT INTO transactions(user_id,amount,type,status)
VALUES(?,?, 'credit','success')
")->execute([$user_id,$amount]);

echo json_encode([
"status"=>"success",
"message"=>"Money added"
]);

?>