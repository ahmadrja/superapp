<?php

require '../../config/database.php';

$user_id = $_POST['user_id'];
$aadhaar = $_POST['aadhaar'];
$pan = $_POST['pan'];

$aadhaar_img = $_FILES['aadhaar_image']['name'];
$pan_img = $_FILES['pan_image']['name'];

move_uploaded_file(
$_FILES['aadhaar_image']['tmp_name'],
"../../uploads/".$aadhaar_img
);

move_uploaded_file(
$_FILES['pan_image']['tmp_name'],
"../../uploads/".$pan_img
);

$stmt = $conn->prepare("
INSERT INTO kyc_documents(user_id,aadhaar,pan,aadhaar_image,pan_image)
VALUES(?,?,?,?,?)
");

$stmt->execute([
$user_id,
$aadhaar,
$pan,
$aadhaar_img,
$pan_img
]);

echo json_encode([
"status"=>"success",
"message"=>"KYC submitted"
]);

?>