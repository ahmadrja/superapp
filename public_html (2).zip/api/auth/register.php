<?php

header("Content-Type: application/json");

require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$name = $data['name'];
$mobile = $data['mobile'];
$password = password_hash($data['password'], PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users(name,mobile,password) VALUES(?,?,?)");
$stmt->execute([$name,$mobile,$password]);

$user_id = $conn->lastInsertId();

$conn->prepare("INSERT INTO wallet(user_id,balance) VALUES(?,0)")
->execute([$user_id]);

echo json_encode([
"status"=>"success",
"user_id"=>$user_id
]);

?>