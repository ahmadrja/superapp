<?php

header("Content-Type: application/json");

require '../../config/database.php';

$user_id = $_GET['user_id'];

$stmt = $conn->prepare("SELECT id,name,mobile,email,kyc_status FROM users WHERE id=?");
$stmt->execute([$user_id]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($user);

?>