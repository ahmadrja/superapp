<?php

header("Content-Type: application/json");

require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$mobile = $data['mobile'];
$password = $data['password'];

$stmt = $conn->prepare("SELECT * FROM users WHERE mobile=?");
$stmt->execute([$mobile]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if($user && password_verify($password,$user['password'])){

echo json_encode([
"status"=>"success",
"user"=>$user
]);

}else{

echo json_encode([
"status"=>"error",
"message"=>"Invalid login"
]);

}

?>