<?php

header("Content-Type: application/json");
require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"),true);

$user_id = $data['user_id'];
$name = $data['name'];
$account = $data['account_number'];
$ifsc = $data['ifsc'];

$stmt = $conn->prepare("
INSERT INTO beneficiaries(user_id,name,account_number,ifsc)
VALUES(?,?,?,?)
");

$stmt->execute([$user_id,$name,$account,$ifsc]);

echo json_encode([
"status"=>"success",
"message"=>"Beneficiary added"
]);

?>