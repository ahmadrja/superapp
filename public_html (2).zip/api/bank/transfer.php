<?php

header("Content-Type: application/json");
require '../../config/database.php';

$data = json_decode(file_get_contents("php://input"),true);

$user_id = $data['user_id'];
$beneficiary_id = $data['beneficiary_id'];
$amount = $data['amount'];

$wallet = $conn->prepare("SELECT balance FROM wallet WHERE user_id=?");
$wallet->execute([$user_id]);
$row = $wallet->fetch(PDO::FETCH_ASSOC);

if($row['balance'] < $amount){

echo json_encode([
"status"=>"error",
"message"=>"Insufficient balance"
]);

exit;

}

$conn->prepare("
UPDATE wallet SET balance = balance - ?
WHERE user_id=?
")->execute([$amount,$user_id]);

$conn->prepare("
INSERT INTO bank_transfers(user_id,beneficiary_id,amount,status)
VALUES(?,?,?,'success')
")->execute([$user_id,$beneficiary_id,$amount]);

$conn->prepare("
INSERT INTO transactions(user_id,amount,type,status)
VALUES(?,?, 'debit','success')
")->execute([$user_id,$amount]);

echo json_encode([
"status"=>"success",
"message"=>"Transfer successful"
]);

?>