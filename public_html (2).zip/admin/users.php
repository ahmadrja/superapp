<?php
require 'includes/header.php';
require '../config/database.php';
require 'includes/sidebar.php';

$users = $conn->query("SELECT * FROM users");
?>

<h3>Users</h3>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Name</th>
<th>Mobile</th>
<th>Email</th>
<th>KYC</th>
</tr>

<?php while($row=$users->fetch(PDO::FETCH_ASSOC)){ ?>

<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['kyc_status']; ?></td>
</tr>

<?php } ?>

</table>

<?php require 'includes/footer.php'; ?>