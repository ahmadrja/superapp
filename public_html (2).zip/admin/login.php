<!DOCTYPE html>
<html>
<head>

<title>Admin Login</title>

<link rel="stylesheet"
href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

</head>

<body class="bg-light">

<div class="container mt-5">

<div class="card p-4">

<h3>Admin Login</h3>

<form action="login_process.php" method="post">

<input type="text"
name="username"
class="form-control mb-3"
placeholder="Username"
required>

<input type="password"
name="password"
class="form-control mb-3"
placeholder="Password"
required>

<button class="btn btn-primary w-100">
Login
</button>

</form>

</div>

</div>

</body>
</html>