<?php

require '../config/database.php';

$data = $conn->query("
SELECT kyc_documents.*,users.name
FROM kyc_documents
JOIN users ON users.id = kyc_documents.user_id
");

?>

<h2>KYC Requests</h2>

<table border="1">

<tr>
<th>User</th>
<th>Aadhaar</th>
<th>PAN</th>
<th>Status</th>
</tr>

<?php while($row=$data->fetch(PDO::FETCH_ASSOC)){ ?>

<tr>

<td><?php echo $row['name']; ?></td>
<td><?php echo $row['aadhaar']; ?></td>
<td><?php echo $row['pan']; ?></td>
<td><?php echo $row['status']; ?></td>

</tr>

<?php } ?>

</table>