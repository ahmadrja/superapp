<div class="col-md-2 sidebar">

<h4 class="p-3">SuperApp</h4>

<a href="dashboard.php">Dashboard</a>

<a href="users.php">Users</a>

<a href="wallet.php">Wallet</a>

<a href="transactions.php">Transactions</a>

<a href="recharges.php">Recharges</a>

<a href="logout.php">Logout</a>

</div>

<div class="col-md-10 p-4">