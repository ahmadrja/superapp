<?php
session_start();

if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>

<title>Admin Panel</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f6f9;
}

.sidebar{
height:100vh;
background:#343a40;
color:white;
}

.sidebar a{
color:white;
display:block;
padding:12px;
text-decoration:none;
}

.sidebar a:hover{
background:#495057;
}

</style>

</head>

<body>

<div class="container-fluid">
<div class="row">