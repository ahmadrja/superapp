<?php
require 'includes/header.php';
require '../config/database.php';
require 'includes/sidebar.php';

$data = $conn->query("
SELECT transactions.*,users.name 
FROM transactions
JOIN users ON users.id = transactions.user_id
ORDER BY transactions.id DESC
");
?>

<h3>Transactions</h3>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>User</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
<th>Date</th>
</tr>

<?php while($row=$data->fetch(PDO::FETCH_ASSOC)){ ?>

<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['amount']; ?></td>
<td><?php echo $row['type']; ?></td>
<td><?php echo $row['status']; ?></td>
<td><?php echo $row['created_at']; ?></td>
</tr>

<?php } ?>

</table>

<?php require 'includes/footer.php'; ?>