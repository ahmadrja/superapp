<?php

require '../config/database.php';

$data = $conn->query("SELECT * FROM operators");

?>

<h2>Operators</h2>

<table border="1">

<tr>
<th>Name</th>
<th>Type</th>
<th>Commission %</th>
</tr>

<?php while($row=$data->fetch(PDO::FETCH_ASSOC)){ ?>

<tr>

<td><?php echo $row['name']; ?></td>
<td><?php echo $row['type']; ?></td>
<td><?php echo $row['commission']; ?></td>

</tr>

<?php } ?>

</table>