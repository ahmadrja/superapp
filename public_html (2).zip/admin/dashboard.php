<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

if(!isset($_SESSION['admin'])){
    header("Location: login.php");
    exit();
}

require '../config/database.php';

/* DASHBOARD DATA */

$users = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
$recharges = $conn->query("SELECT COUNT(*) FROM recharges")->fetchColumn();
$transactions = $conn->query("SELECT COUNT(*) FROM transactions")->fetchColumn();

?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Super App Admin Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
background:#f4f6f9;
}

.sidebar{
height:100vh;
background:#343a40;
}

.sidebar a{
color:white;
display:block;
padding:12px;
text-decoration:none;
}

.sidebar a:hover{
background:#495057;
}

.card{
border:none;
border-radius:10px;
box-shadow:0px 2px 6px rgba(0,0,0,0.1);
}

</style>

</head>

<body>

<div class="container-fluid">

<div class="row">

<!-- SIDEBAR -->

<div class="col-md-2 sidebar">

<h4 class="text-white p-3">SuperApp</h4>

<a href="dashboard.php">Dashboard</a>
<a href="users.php">Users</a>
<a href="wallet.php">Wallet</a>
<a href="transactions.php">Transactions</a>
<a href="recharges.php">Recharges</a>
<a href="logout.php">Logout</a>

</div>

<!-- MAIN CONTENT -->

<div class="col-md-10">

<nav class="navbar navbar-light bg-white shadow-sm">

<div class="container-fluid">

<span class="navbar-brand">Admin Dashboard</span>

</div>

</nav>

<div class="container mt-4">

<div class="row">

<!-- USERS -->

<div class="col-md-4">

<div class="card p-3">

<h6>Total Users</h6>

<h2><?php echo $users; ?></h2>

</div>

</div>

<!-- RECHARGES -->

<div class="col-md-4">

<div class="card p-3">

<h6>Total Recharges</h6>

<h2><?php echo $recharges; ?></h2>

</div>

</div>

<!-- TRANSACTIONS -->

<div class="col-md-4">

<div class="card p-3">

<h6>Total Transactions</h6>

<h2><?php echo $transactions; ?></h2>

</div>

</div>

</div>

<hr>

<h5>Recent Transactions</h5>

<table class="table table-bordered">

<tr>

<th>ID</th>
<th>User ID</th>
<th>Amount</th>
<th>Type</th>
<th>Status</th>
<th>Date</th>

</tr>

<?php

$data = $conn->query("SELECT * FROM transactions ORDER BY id DESC LIMIT 10");

while($row=$data->fetch(PDO::FETCH_ASSOC)){

?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['user_id']; ?></td>
<td><?php echo $row['amount']; ?></td>
<td><?php echo $row['type']; ?></td>
<td><?php echo $row['status']; ?></td>
<td><?php echo $row['created_at']; ?></td>

</tr>

<?php } ?>

</table>

</div>

</div>

</div>

</div>

</div>

</body>

</html>