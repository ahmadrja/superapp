<?php

require 'includes/header.php';
require '../config/database.php';
require 'includes/sidebar.php';

$data = $conn->query("
SELECT wallet.id,users.name,wallet.balance,wallet.user_id
FROM wallet
JOIN users ON users.id = wallet.user_id
");

?>

<h3>Wallet Management</h3>

<table class="table table-bordered">

<tr>
<th>User</th>
<th>Balance</th>
<th>Add/Deduct</th>
</tr>

<?php while($row=$data->fetch(PDO::FETCH_ASSOC)){ ?>

<tr>

<td><?php echo $row['name']; ?></td>

<td>₹ <?php echo $row['balance']; ?></td>

<td>

<form action="wallet_update.php" method="post">

<input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">

<input type="number" name="amount" class="form-control mb-2" placeholder="Amount">

<select name="type" class="form-control mb-2">

<option value="credit">Add</option>
<option value="debit">Deduct</option>

</select>

<button class="btn btn-primary btn-sm">Submit</button>

</form>

</td>

</tr>

<?php } ?>

</table>

<?php require 'includes/footer.php'; ?>