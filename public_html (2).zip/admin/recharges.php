<?php

require 'includes/header.php';
require '../config/database.php';
require 'includes/sidebar.php';

$data = $conn->query("
SELECT recharges.*,users.name
FROM recharges
JOIN users ON users.id = recharges.user_id
ORDER BY recharges.id DESC
");

?>

<h3>Recharge Requests</h3>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>User</th>
<th>Number</th>
<th>Operator</th>
<th>Amount</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php while($row=$data->fetch(PDO::FETCH_ASSOC)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['number']; ?></td>
<td><?php echo $row['operator']; ?></td>
<td><?php echo $row['amount']; ?></td>
<td><?php echo $row['status']; ?></td>

<td>

<a class="btn btn-success btn-sm"
href="recharge_action.php?id=<?php echo $row['id']; ?>&status=success">

Approve

</a>

<a class="btn btn-danger btn-sm"
href="recharge_action.php?id=<?php echo $row['id']; ?>&status=failed">

Reject

</a>

</td>

</tr>

<?php } ?>

</table>

<?php require 'includes/footer.php'; ?>