<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require '../config/database.php';

if(!isset($_POST['username']) || !isset($_POST['password'])){
    die("Form data missing");
}

$username = trim($_POST['username']);
$password = trim($_POST['password']);

$stmt = $conn->prepare("SELECT * FROM admins WHERE username = ?");
$stmt->execute([$username]);

$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if($admin){

    if(password_verify($password,$admin['password'])){

        $_SESSION['admin']=$admin['username'];

        header("Location: dashboard.php");
        exit();

    }else{
        echo "Password incorrect";
    }

}else{

    echo "Admin user not found";

}

?>