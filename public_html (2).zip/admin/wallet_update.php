<?php

require '../config/database.php';

$user_id = $_POST['user_id'];
$amount = $_POST['amount'];
$type = $_POST['type'];

if($type=="credit"){

$conn->prepare("UPDATE wallet SET balance = balance + ? WHERE user_id=?")
->execute([$amount,$user_id]);

}else{

$conn->prepare("UPDATE wallet SET balance = balance - ? WHERE user_id=?")
->execute([$amount,$user_id]);

}

$conn->prepare("INSERT INTO transactions(user_id,amount,type,status)
VALUES(?,?,?,'success')")
->execute([$user_id,$amount,$type]);

header("Location: wallet.php");

?>