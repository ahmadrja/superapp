<?php

require '../config/database.php';

$id = $_GET['id'];
$status = $_GET['status'];

$conn->prepare("UPDATE recharges SET status=? WHERE id=?")
->execute([$status,$id]);

header("Location: recharges.php");

?>