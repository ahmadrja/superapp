<?php

$host="localhost";
$db="u433139141_superapp";
$user="u433139141_superapp";
$pass="Ahmad@0201";

try{

$conn = new PDO("mysql:host=$host;dbname=$db",$user,$pass);
$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

}catch(PDOException $e){

echo $e->getMessage();

}

?>